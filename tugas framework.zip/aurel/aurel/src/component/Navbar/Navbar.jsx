import React from 'react'
import './style.css'

const Navbar = () => {
  return (
    <div className='navbar-container'>
        <h1>Call a Friend</h1>
        <h5 className='garis'>your friend contact app</h5>
    </div>
  )
}

export default Navbar